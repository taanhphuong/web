<?php

  include ("trust/config.php");

  include ("trust/head.php");

  include ("templates/main-mine.php");

  include ("templates/view_mine.php");

  include ("trust/foot.php");

?>