<?php

  include ("trust/config.php");

  include ("trust/head.php");

  include ("trust/main.php");

  include ("templates/view_pages.php");

  include ("trust/foot.php");

?>