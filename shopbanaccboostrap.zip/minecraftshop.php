<?php

include ("trust/config.php");

include ("trust/head.php");

include ("templates/main-mine.php");

include ("templates/minecraft.php");

include ("trust/foot.php");

?>