<?php

	echo "<script>swal('Sorry', 'Chức Năng Đang Xây Dựng!', 'info')</script>";

?>