<?php

include ("trust/config.php");

include ("trust/head.php");

include ("trust/main.php");

include ("trust/foot.php");

?>