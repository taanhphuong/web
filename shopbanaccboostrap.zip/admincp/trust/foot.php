<footer>
	
</footer>

<script type="text/javascript" src="assets/js/bootstrap-3.3.5.js"></script>
</body>
</html>