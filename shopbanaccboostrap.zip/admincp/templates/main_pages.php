<div id="mainindex" class="container margin-top-20px">
	<div class="row">
		<div class="col-sm-4">
			<div class="panel panel-primary">
				<div class="panel-heading">Menu</div>
				<div class="list-group">
					<a class="list-group-item" href="index.php">Trang Chủ</a>
					<a class="list-group-item" href="index.php?act=post">Đăng Tài Khoản LOL</a>
					<a class="list-group-item" href="index.php?act=manager">Quản Lý Tài Khoản</a>
					<a class="list-group-item" href="index.php?act=member">Quản Lý Người Dùng</a>
					<a class="list-group-item" href="index.php?act=payment">Quản Lý Nạp Thẻ</a>
				</div>
			</div>
		</div>
		<div class="col-sm-8">
			<?php include ("templates/controller.php"); ?>
		</div>
	</div>
</div>