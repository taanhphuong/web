<?php

include ("trust/config.php");

include ("trust/head.php");

include ("trust/main.php");

include ("templates/history.php");

include ("trust/foot.php");

?>